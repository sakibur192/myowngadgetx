# Clip Setter + OTP Filler — for the target phone

The target phone's OTP field only accepts input it considers **genuine** (a real
keystroke/paste). A programmatic clipboard-set + tap fills the boxes visually but the app
does not treat it as real, so Confirm never activates. The fix is an **Accessibility
Service**: accessibility actions (set-text / paste) are first-class system input that fire
the app's real validation — exactly like a human. This is how password managers fill fields.

Install on the **TARGET phone** (where GadgetX runs).

## What's inside
- `OtpAccessibilityService.kt` — fills the OTP field as genuine input on command.
- `ClipActivity.kt` — tiny clipboard setter (kept as a fallback).

## Build in Android Studio
1. **New Project → Empty Views Activity**, package = `com.baybex.clipsetter`, Kotlin.
2. Delete the generated MainActivity; add `ClipActivity.kt` and `OtpAccessibilityService.kt`
   under `app/src/main/java/com/baybex/clipsetter/`.
3. Add `app/src/main/res/xml/accessibility_config.xml` and `res/values/strings.xml`
   (from this folder).
4. Replace `app/src/main/AndroidManifest.xml` with the one here.
5. **Run ▶** / Build APK and install on the phone.

## Enable it (one time)
On the phone: **Settings → Accessibility → GadgetX OTP Filler → turn ON** (allow).
It stays enabled across reboots.

## How the server uses it
The server (otpMode: 'a11y') broadcasts the OTP; the service fills the boxes as genuine input:
```
am broadcast -a com.baybex.clipsetter.SET_OTP --es text 1234 --es mode settext -p com.baybex.clipsetter
```
- `mode settext` (default): sets each box's text via ACTION_SET_TEXT (fires the app's validation).
- `mode paste`: sets the clipboard, focuses the first field, performs a REAL ACTION_PASTE.
  (Set the server to otpMode: 'a11y-paste' to use this instead.)

## Quick test (device connected, on the VPS)
1. Open the GadgetX OTP screen on the phone.
2. Run:
```bash
adb -s 127.0.0.1:5555 shell am broadcast -a com.baybex.clipsetter.SET_OTP --es text 1234 --es mode settext -p com.baybex.clipsetter
```
The boxes should fill with 1234 **and Confirm should become active** (unlike the paste method).
If nothing happens, the accessibility service isn't enabled — see "Enable it" above.
