package com.baybex.clipsetter

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.method.ScrollingMovementMethod
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// ============================ CONFIG ============================
const val SERVER_URL = "http://76.13.223.236:3900"
const val API_KEY    = "76344d7de4bda46b0bea0cf8717088e352e0c1c534474abb"
// ================================================================

// OTP Viewer screen inside Clip Setter. Polls the server for the latest OTP/SMS (sent from
// /flow or forwarded from the SIM phone). You tap "Copy OTP", switch to GadgetX, and paste
// by hand into the OTP field.
class MainActivity : AppCompatActivity() {

    private lateinit var otpView: TextView
    private lateinit var smsView: TextView
    private lateinit var metaView: TextView
    private val h = Handler(Looper.getMainLooper())
    private var lastId = 0L
    private var otp = ""
    private var sms = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 56, 48, 56) }
        fun label(t: String, s: Float, top: Int = 0) = TextView(this).apply { text = t; textSize = s; setPadding(0, top, 0, 8) }

        root.addView(label("GadgetX OTP", 20f))
        root.addView(label("Waiting for the OTP…", 13f).also { metaView = it })

        otpView = TextView(this).apply {
            textSize = 42f; gravity = Gravity.CENTER; setPadding(0, 28, 0, 20)
            text = "—"; setTextIsSelectable(true)
        }
        root.addView(otpView)

        root.addView(Button(this).apply {
            text = "Copy OTP"
            setOnClickListener { if (otp.isNotEmpty()) copy(otp, "OTP copied: $otp") else toast("No OTP yet") }
        })
        root.addView(Button(this).apply {
            text = "Copy full SMS"
            setOnClickListener { if (sms.isNotEmpty()) copy(sms, "SMS copied") else toast("No SMS yet") }
        })

        root.addView(label("Full SMS:", 13f, 24))
        smsView = TextView(this).apply {
            textSize = 15f; setTextIsSelectable(true); movementMethod = ScrollingMovementMethod()
            setPadding(0, 6, 0, 0); text = "—"
        }
        root.addView(smsView)

        root.addView(label("Tap Copy OTP, then switch to GadgetX and long-press the OTP field → Paste.", 12f, 24))
        setContentView(root)
        poll()
    }

    private fun copy(text: String, msg: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("otp", text))
        toast(msg)
    }
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun poll() {
        Thread {
            val body = try { httpGet("/api/last-sms") } catch (_: Exception) { null }
            h.post {
                if (body != null) {
                    try {
                        val j = JSONObject(body)
                        if (j.optBoolean("has", false)) {
                            val id = j.optLong("id")
                            otp = j.optString("otp", "")
                            sms = j.optString("message", "")
                            otpView.text = if (otp.isNotEmpty()) otp else "(no code found)"
                            smsView.text = sms
                            val fresh = id != lastId
                            lastId = id
                            metaView.text = (if (fresh) "NEW · " else "") + "from " + j.optString("from", "?") + " · " + j.optString("at", "")
                        } else metaView.text = "Waiting for the OTP…"
                    } catch (_: Exception) {}
                } else metaView.text = "Server unreachable — retrying…"
            }
            h.postDelayed({ poll() }, 2000)
        }.start()
    }

    private fun httpGet(path: String): String? {
        val c = (URL(SERVER_URL.trimEnd('/') + path).openConnection() as HttpURLConnection)
        c.requestMethod = "GET"; c.connectTimeout = 8000; c.readTimeout = 10000
        c.setRequestProperty("x-api-key", API_KEY)
        val code = c.responseCode
        val s = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }
        c.disconnect(); return s
    }
}
