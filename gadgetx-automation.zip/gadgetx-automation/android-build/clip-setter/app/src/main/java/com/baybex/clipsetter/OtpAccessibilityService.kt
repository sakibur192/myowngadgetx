package com.baybex.clipsetter

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

// Fills the OTP field as GENUINE input, so the app's validation fires exactly like a real
// user typing/pasting. The server triggers it with:
//   am broadcast -a com.baybex.clipsetter.SET_OTP --es text 1234 -p com.baybex.clipsetter
// Modes (extra "mode"): "settext" (default) sets each box's text via ACTION_SET_TEXT;
//                        "paste" sets the clipboard then performs ACTION_PASTE on the field.
// Enable once:  Settings -> Accessibility -> GadgetX OTP Filler -> On.
class OtpAccessibilityService : AccessibilityService() {

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent == null) return
            val mode = intent.getStringExtra("mode") ?: "settext"
            val b64 = intent.getStringExtra("b64")
            val text = if (!b64.isNullOrEmpty())
                try { String(Base64.decode(b64, Base64.DEFAULT), Charsets.UTF_8) } catch (_: Exception) { "" }
            else (intent.getStringExtra("text") ?: "")
            // paste mode ignores text (clipboard is already set by the server)
            if (mode != "paste" && text.isEmpty()) return
            try { fill(text, mode) } catch (_: Exception) {}
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val filter = IntentFilter("com.baybex.clipsetter.SET_OTP")
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(receiver, filter)
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun collectEditable(node: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (node == null) return
        val cls = node.className?.toString() ?: ""
        if (node.isEditable || cls.contains("EditText")) out.add(node)
        for (i in 0 until node.childCount) collectEditable(node.getChild(i), out)
    }

    // The OTP field to act on: the focused editable node if there is one, else the first editable.
    private fun targetField(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (focused != null && focused.isEditable) return focused
        val fields = mutableListOf<AccessibilityNodeInfo>()
        collectEditable(root, fields)
        return fields.firstOrNull()
    }

    private fun fill(text: String, mode: String) {
        val target = targetField() ?: return
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)

        if (mode == "paste") {
            // The server already put the text on the clipboard. Perform a REAL paste into
            // the focused field — identical to the user tapping Paste by hand.
            target.performAction(AccessibilityNodeInfo.ACTION_PASTE)
            return
        }

        // settext: put the WHOLE string into the focused field (no scattering across boxes).
        // A single underlying OTP field distributes it into the visual boxes itself.
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }
}
