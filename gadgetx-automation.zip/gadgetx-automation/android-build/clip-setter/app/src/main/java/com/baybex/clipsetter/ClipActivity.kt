package com.baybex.clipsetter

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.util.Base64

// A tiny invisible helper. Launched by the server with the OTP as an intent extra,
// it sets the system clipboard (a foreground app is allowed to, unlike the adb shell),
// then finishes immediately. The server then taps the OTP field and pastes.
//
// Launch it from the server like:
//   am start -n com.baybex.clipsetter/.ClipActivity --es b64 <BASE64_OF_TEXT>
// or (plain, no spaces/newlines):
//   am start -n com.baybex.clipsetter/.ClipActivity --es text 1234
class ClipActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = readText(intent?.getStringExtra("b64"), intent?.getStringExtra("text"))
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("otp", text))
        } catch (_: Exception) {
        }
        finish()
    }

    private fun readText(b64: String?, plain: String?): String {
        if (!b64.isNullOrEmpty()) {
            return try { String(Base64.decode(b64, Base64.DEFAULT), Charsets.UTF_8) } catch (_: Exception) { "" }
        }
        return plain ?: ""
    }
}
