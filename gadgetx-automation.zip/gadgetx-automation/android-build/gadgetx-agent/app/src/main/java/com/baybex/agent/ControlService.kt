package com.baybex.agent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

// The hands + eyes on the phone. The AgentService hands it a command; it performs the
// gesture / text / screenshot / screen-read through the accessibility framework.
class ControlService : AccessibilityService() {

    companion object {
        @Volatile var instance: ControlService? = null
        fun isReady() = instance != null
    }

    // The foreground app + screen, tracked from window-change events (best signal for the Activity).
    @Volatile private var lastPackage: String = ""
    @Volatile private var lastActivity: String = ""

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val cls = event.className?.toString() ?: ""
            val pkg = event.packageName?.toString() ?: ""
            // keep real app screens (a class name with a dot), drop framework popups
            if (cls.contains(".") && !cls.startsWith("android.view") && !cls.startsWith("android.widget")) {
                lastActivity = cls
                lastPackage = pkg
            }
        }
    }

    // ---- gestures ----
    private fun gesture(path: Path, durationMs: Long): Boolean {
        val gd = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(1)))
            .build()
        val latch = CountDownLatch(1)
        var ok = false
        val posted = dispatchGesture(gd, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { ok = false; latch.countDown() }
        }, null)
        if (!posted) return false
        latch.await(10, TimeUnit.SECONDS)
        return ok
    }

    fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return gesture(p, 50)
    }

    fun longpress(x: Float, y: Float, ms: Long): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return gesture(p, if (ms > 0) ms else 700)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        return gesture(p, if (ms > 0) ms else 300)
    }

    // ---- text / clipboard ----
    private fun focusedEditable(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (f != null && f.isEditable) return f
        return firstEditable(root)
    }

    private fun firstEditable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        val cls = node.className?.toString() ?: ""
        if (node.isEditable || cls.contains("EditText")) return node
        for (i in 0 until node.childCount) { firstEditable(node.getChild(i))?.let { return it } }
        return null
    }

    fun setText(text: String): Boolean {
        val n = focusedEditable() ?: return false
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun setClip(text: String): Boolean {
        return try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("otp", text)); true
        } catch (_: Exception) { false }
    }

    fun paste(): Boolean {
        val n = focusedEditable() ?: return false
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        return n.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }

    fun globalKey(key: String): Boolean {
        val action = when (key.uppercase()) {
            "BACK" -> GLOBAL_ACTION_BACK
            "HOME" -> GLOBAL_ACTION_HOME
            "RECENTS", "APP_SWITCH" -> GLOBAL_ACTION_RECENTS
            "NOTIFICATIONS" -> GLOBAL_ACTION_NOTIFICATIONS
            else -> return false
        }
        return performGlobalAction(action)
    }

    // ---- which screen are we on (package + Activity class) ----
    fun foreground(): JSONObject {
        val root = rootInActiveWindow
        val pkg = root?.packageName?.toString() ?: lastPackage
        return JSONObject().put("package", pkg).put("activity", lastActivity)
    }

    // ---- read the whole screen as a flat list of nodes (same shape the server expects) ----
    fun dumpNodesJson(): JSONArray {
        val arr = JSONArray()
        walk(rootInActiveWindow, arr)
        return arr
    }
    private fun walk(n: AccessibilityNodeInfo?, arr: JSONArray) {
        if (n == null) return
        val r = Rect(); n.getBoundsInScreen(r)
        if (r.width() > 0 && r.height() > 0) {
            arr.put(JSONObject()
                .put("text", n.text?.toString() ?: "")
                .put("desc", n.contentDescription?.toString() ?: "")
                .put("id", n.viewIdResourceName ?: "")
                .put("cls", n.className?.toString() ?: "")
                .put("clickable", n.isClickable)
                .put("enabled", n.isEnabled)
                .put("focused", n.isFocused)
                .put("bounds", JSONArray().put(r.left).put(r.top).put(r.right).put(r.bottom))
                .put("x", (r.left + r.right) / 2)
                .put("y", (r.top + r.bottom) / 2))
        }
        for (i in 0 until n.childCount) walk(n.getChild(i), arr)
    }

    // ---- launch an app by package (no root needed) ----
    fun launchApp(pkg: String): Boolean {
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        return true
    }

    // ---- run a shell command as ROOT (only works if the phone is rooted; else returns an error) ----
    fun shellSu(cmd: String): String {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
            p.waitFor()
            out.trim()
        } catch (e: Exception) { "SU_ERROR: " + (e.message ?: "no su / not rooted") }
    }

    // ---- screenshot (API 30+) ----
    fun screenshotBase64(): String? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1)
        var out: String? = null
        takeScreenshot(Display.DEFAULT_DISPLAY, { it.run() }, object : TakeScreenshotCallback {
            override fun onSuccess(res: ScreenshotResult) {
                try {
                    val hb = res.hardwareBuffer
                    val bmp = Bitmap.wrapHardwareBuffer(hb, res.colorSpace)
                    hb.close()
                    if (bmp != null) {
                        val soft = bmp.copy(Bitmap.Config.ARGB_8888, false)
                        val bos = ByteArrayOutputStream()
                        soft.compress(Bitmap.CompressFormat.JPEG, 70, bos)
                        out = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
                    }
                } catch (_: Exception) {}
                latch.countDown()
            }
            override fun onFailure(errorCode: Int) { latch.countDown() }
        })
        latch.await(6, TimeUnit.SECONDS)
        return out
    }
}
