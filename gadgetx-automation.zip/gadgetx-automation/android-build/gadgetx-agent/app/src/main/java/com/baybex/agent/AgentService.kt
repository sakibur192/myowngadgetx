package com.baybex.agent

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import org.json.JSONObject
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL

// Foreground service. Connects OUT to the VPS and long-polls for commands, forever.
// No adb, no tunnel, no PC. Survives IP changes and works on WiFi or mobile data.
class AgentService : Service() {

    @Volatile private var running = false
    private var thread: Thread? = null

    companion object {
        const val CH = "agent"
        @Volatile var status: String = "starting"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, notif("GadgetX Agent running"))
        if (!running) { running = true; thread = Thread { loop() }.apply { isDaemon = true; start() } }
        return START_STICKY
    }

    override fun onDestroy() { running = false; super.onDestroy() }

    private fun loop() {
        while (running) {
            try {
                val body = httpGet("/api/agent/poll?device=" + enc(DEVICE_ID), 35000)
                status = "connected"
                if (body.isNullOrBlank() || body == "{}") continue
                val j = JSONObject(body)
                val cmd = j.optJSONObject("cmd") ?: continue
                handle(cmd)
            } catch (e: Exception) {
                status = "reconnecting (" + (e.message ?: "net") + ")"
                sleep(2000)
            }
        }
    }

    private fun handle(cmd: JSONObject) {
        val id = cmd.optString("id")
        val type = cmd.optString("type")
        val c = ControlService.instance
        val result = JSONObject().put("id", id)
        if (c == null) {
            post("/api/agent/result", result.put("ok", false).put("error", "accessibility service not enabled").toString())
            return
        }
        try {
            when (type) {
                "tap" -> ok(result, c.tap(f(cmd, "x"), f(cmd, "y")))
                "longpress" -> ok(result, c.longpress(f(cmd, "x"), f(cmd, "y"), cmd.optLong("ms", 700)))
                "swipe" -> ok(result, c.swipe(f(cmd, "x1"), f(cmd, "y1"), f(cmd, "x2"), f(cmd, "y2"), cmd.optLong("ms", 300)))
                "text" -> ok(result, c.setText(cmd.optString("text")))
                "setclip" -> ok(result, c.setClip(cmd.optString("text")))
                "paste" -> ok(result, c.paste())
                "key" -> ok(result, c.globalKey(cmd.optString("key")))
                "screenshot" -> {
                    val b64 = c.screenshotBase64()
                    if (b64 != null) result.put("ok", true).put("data", b64)
                    else result.put("ok", false).put("error", "screenshot unsupported (<API30) or failed")
                }
                "getscreen" -> result.put("ok", true).put("data", c.foreground())
                "dumpui" -> result.put("ok", true).put("data", c.dumpNodesJson())
                "launch" -> ok(result, c.launchApp(cmd.optString("pkg")))
                "shell" -> result.put("ok", true).put("data", c.shellSu(cmd.optString("cmd")))
                "ping" -> result.put("ok", true)
                else -> result.put("ok", false).put("error", "unknown command: $type")
            }
        } catch (e: Exception) {
            result.put("ok", false).put("error", e.message ?: "error")
        }
        post("/api/agent/result", result.toString())
    }

    private fun ok(res: JSONObject, b: Boolean) {
        res.put("ok", b); if (!b) res.put("error", "action returned false")
    }

    private fun f(o: JSONObject, k: String) = o.optDouble(k, 0.0).toFloat()

    // ---- http ----
    private fun httpGet(path: String, timeoutMs: Int): String? {
        val c = (URL(SERVER_URL.trimEnd('/') + path).openConnection() as HttpURLConnection)
        c.requestMethod = "GET"
        c.connectTimeout = 10000
        c.readTimeout = timeoutMs
        c.setRequestProperty("x-api-key", API_KEY)
        val code = c.responseCode
        val s = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }
        c.disconnect()
        return s
    }

    private fun post(path: String, json: String) {
        try {
            val c = (URL(SERVER_URL.trimEnd('/') + path).openConnection() as HttpURLConnection)
            c.requestMethod = "POST"
            c.connectTimeout = 10000
            c.readTimeout = 15000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-api-key", API_KEY)
            c.outputStream.use { out: OutputStream -> out.write(json.toByteArray(Charsets.UTF_8)) }
            c.responseCode
            c.disconnect()
        } catch (_: Exception) {}
    }

    private fun enc(s: String) = java.net.URLEncoder.encode(s, "UTF-8")
    private fun sleep(ms: Long) { try { Thread.sleep(ms) } catch (_: Exception) {} }

    private fun notif(text: String): Notification {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CH) == null) {
                nm.createNotificationChannel(NotificationChannel(CH, "GadgetX Agent", NotificationManager.IMPORTANCE_LOW))
            }
            return Notification.Builder(this, CH).setContentTitle("GadgetX Agent").setContentText(text)
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth).setOngoing(true).build()
        }
        @Suppress("DEPRECATION")
        return Notification.Builder(this).setContentTitle("GadgetX Agent").setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth).build()
    }
}
