package com.baybex.agent

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private val h = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 56, 48, 56) }
        fun label(t: String, s: Float, top: Int = 0) = TextView(this).apply { text = t; textSize = s; setPadding(0, top, 0, 8) }

        root.addView(label("GadgetX Agent", 24f))
        root.addView(label("Server: $SERVER_URL", 13f))
        root.addView(label("Device: $DEVICE_ID", 13f))

        root.addView(Button(this).apply {
            text = "1 · Enable Accessibility"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "2 · Start Agent"
            setOnClickListener {
                val i = Intent(this@MainActivity, AgentService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            }
        })

        status = label("…", 15f, 24)
        root.addView(status)
        root.addView(label("Keep this app installed. The agent runs in the background and reconnects on its own. Enable Accessibility once; it survives reboots.", 12f, 16))

        setContentView(ScrollView(this).apply { addView(root) })
        tick()
    }

    private fun tick() {
        val a11y = if (ControlService.isReady()) "ON" else "OFF — tap step 1"
        status.text = "Accessibility: $a11y\nAgent: " + AgentService.status
        h.postDelayed({ tick() }, 1000)
    }
}
