package com.baybex.agent

// ============================ CONFIG ============================
// The VPS control server. The phone connects OUT to this — no PC, no adb, no tunnel.
const val SERVER_URL = "http://76.13.223.236:3900"
const val API_KEY    = "76344d7de4bda46b0bea0cf8717088e352e0c1c534474abb"
// A name for this phone (shows in the server logs). Any text.
const val DEVICE_ID  = "phone-1"
// ================================================================
