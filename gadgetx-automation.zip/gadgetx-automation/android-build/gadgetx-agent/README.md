# GadgetX Agent — phone connects itself to the VPS (no PC, no USB, no tunnel)

The phone runs a small app that **dials OUT** to your VPS and long‑polls for commands,
then performs them with Android's Accessibility service (taps, typing, clipboard, paste,
reading the screen, screenshots, launching the app). Because the phone connects out, it
works on home Wi‑Fi / mobile data behind NAT — nothing to forward, no tunnel.

```
 phone (GadgetX Agent)  ──connects OUT──▶  VPS control server (:3900)
        ▲  long-polls /api/agent/poll  ·  posts results to /api/agent/result
```

## What it can do on its own (NO root needed)
- taps, long‑press, swipe
- type into fields, set clipboard, paste
- Back / Home / Recents
- read which screen is showing (for the Home/Login/Register decision)
- read the screen's elements (for Check)
- take screenshots (Android 11+ / API 30+)
- launch the app

## What needs ROOT (only used by Start Over / Register / Show‑tap‑marks)
- wipe app data (`pm clear`), grant permissions (`pm grant`), secure settings (`settings put`)

These run via `su`. **If the phone is not rooted, those three features won't work in agent
mode** — everything else (login, send, out, check, and the registration *tapping/OTP*) works
fine. (Wipe/grant can still be done the old adb way, or by hand.)

## Build & install (Android Studio)
1. New Project → **Empty Views Activity**, package **`com.baybex.agent`**, language **Kotlin**.
2. Replace / add these files (same paths as here):
   - `app/src/main/java/com/baybex/agent/Config.kt`
   - `app/src/main/java/com/baybex/agent/AgentService.kt`
   - `app/src/main/java/com/baybex/agent/ControlService.kt`
   - `app/src/main/java/com/baybex/agent/MainActivity.kt`
   - `app/src/main/AndroidManifest.xml`
   - `app/src/main/res/xml/accessibility_config.xml`
   - `app/src/main/res/values/strings.xml`
3. `Config.kt` already has your server + key:
   - `SERVER_URL = http://76.13.223.236:3900`
   - `API_KEY = 76344d7de4bda46b0bea0cf8717088e352e0c1c534474abb`
4. Build → install on the phone.

## Turn it on (once)
1. Open **GadgetX Agent**.
2. Tap **1 · Enable Accessibility** → turn **GadgetX Agent** ON in the list.
3. Tap **2 · Start Agent**. The screen shows `Accessibility: ON` and `Agent: connected`.
4. (Optional, for reliability) in the phone's battery settings, set the app to **Unrestricted**
   / disable battery optimization so Android doesn't kill the background service.

The agent reconnects on its own and survives IP changes and reboots (re‑open it once after a
reboot if the service doesn't auto‑start).

## Switch the server to use the agent
On the VPS, run the control server with `TRANSPORT=agent`:
```
cd /opt/myowngadgetx
TRANSPORT=agent pm2 restart gadgetx-control --update-env
```
(To go back to the PC+tunnel way: `TRANSPORT=adb pm2 restart gadgetx-control --update-env`.)

## Check it's connected
```
curl -s -H "x-api-key: 76344d7de4bda46b0bea0cf8717088e352e0c1c534474abb" http://76.13.223.236:3900/api/status
```
Then use `/mydashboard` exactly as before — Login / Send / Out / Check all run through the phone now.
```
