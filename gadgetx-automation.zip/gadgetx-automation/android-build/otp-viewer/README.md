# Manual-OTP setup — SMS Forwarder + OTP Viewer

The app only accepts a fully-manual OTP copy+paste. So: the SIM phone forwards the OTP SMS
to the server, the OTP Viewer shows it on the TARGET phone, and you copy + paste it by hand.

```
SIM phone (SMS Forwarder)  ──POST /api/sms──▶  server  ◀──poll /api/last-sms──  target phone (OTP Viewer)
                                                                                  you tap Copy, then paste in GadgetX
```

## 1) SMS Forwarder  → install on the SIM phone (android-build/sms-forwarder)
- Android Studio → New Project → Empty Views Activity, package `com.baybex.smsforwarder`, Kotlin.
- Add `SmsReceiver.kt` + `MainActivity.kt`, replace `AndroidManifest.xml` with the one here.
- Install, open it once, **Grant SMS permission**. Done — it forwards every incoming SMS to
  the server automatically, even closed.

## 2) OTP Viewer  → install on the TARGET phone (android-build/otp-viewer)
- New Project → Empty Views Activity, package `com.baybex.otpviewer`, Kotlin.
- Add `MainActivity.kt`, replace `AndroidManifest.xml`.
- Install. Open it — it polls the server and shows the latest OTP with a **Copy OTP** button.

## Using it (per registration)
1. Server does mobile + PIN (via /flow or the register steps) — this still uses the tunnel for now.
2. The OTP SMS arrives on the SIM phone → forwarded → appears in **OTP Viewer** on the target phone.
3. On the target phone: open OTP Viewer, tap **Copy OTP** (or long-press the text and Copy).
4. Switch to GadgetX, long-press the OTP field → **Paste** (your hand). Tap Confirm.

Because the copy and the paste are both done by your hand, the app accepts it like normal.

## Server
`/api/sms` (POST) already receives forwarded SMS. `/api/last-sms` (GET) serves the latest to
the viewer. Nothing else to configure. Both apps have SERVER_URL + API_KEY filled in.
