package com.baybex.smsforwarder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL

// ============================ CONFIG ============================
const val SERVER_URL = "http://76.13.223.236:3900"
const val API_KEY    = "76344d7de4bda46b0bea0cf8717088e352e0c1c534474abb"
// ================================================================

// Install on the SIM phone. Every incoming SMS is forwarded to the server as-is (whole text,
// any sender), which then shows it on the OTP Viewer on the target phone.
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent?.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        val from = msgs.firstOrNull()?.displayOriginatingAddress ?: ""
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        if (body.isBlank()) return
        // Network off the main thread.
        Thread { forward(from, body) }.start()
    }

    private fun forward(from: String, body: String) {
        try {
            val c = (URL(SERVER_URL.trimEnd('/') + "/api/sms").openConnection() as HttpURLConnection)
            c.requestMethod = "POST"
            c.connectTimeout = 10000
            c.readTimeout = 15000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-api-key", API_KEY)
            val json = "{\"from\":" + q(from) + ",\"message\":" + q(body) + "}"
            c.outputStream.use { out: OutputStream -> out.write(json.toByteArray(Charsets.UTF_8)) }
            c.responseCode
            c.disconnect()
        } catch (_: Exception) {}
    }

    private fun q(s: String): String {
        val sb = StringBuilder("\"")
        for (ch in s) when (ch) {
            '\\' -> sb.append("\\\\"); '"' -> sb.append("\\\"")
            '\n' -> sb.append("\\n"); '\r' -> sb.append("\\r"); '\t' -> sb.append("\\t")
            else -> if (ch < ' ') sb.append(' ') else sb.append(ch)
        }
        return sb.append("\"").toString()
    }
}
