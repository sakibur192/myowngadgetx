package com.baybex.smsforwarder

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

// Just a permission screen. Once SMS permission is granted, the receiver forwards every
// incoming SMS to the server on its own (even when this app is closed).
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 64, 48, 64) }
        fun label(t: String, s: Float, top: Int = 0) = TextView(this).apply { text = t; textSize = s; setPadding(0, top, 0, 8) }

        root.addView(label("GadgetX SMS Forwarder", 22f))
        root.addView(label("Server: $SERVER_URL", 13f))
        root.addView(label("Every incoming SMS is forwarded to the server automatically. Grant SMS permission once.", 14f, 16))

        val status = label("…", 15f, 20)
        root.addView(Button(this).apply {
            text = "Grant SMS permission"
            setOnClickListener {
                ActivityCompat.requestPermissions(this@MainActivity,
                    arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS), 1)
            }
        })
        root.addView(status)
        setContentView(root)

        fun refresh() {
            val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
            status.text = if (granted) "✓ SMS permission granted — forwarding is active." else "SMS permission NOT granted yet."
        }
        refresh()
        window.decorView.post { refresh() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        recreate()
    }
}
